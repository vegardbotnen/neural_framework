## Neural Framework

Simple, but yet powerful neural computation framework for fast prototyping.

#### Import
```python
from neural_framework import brain
```


#### Use
```python

```