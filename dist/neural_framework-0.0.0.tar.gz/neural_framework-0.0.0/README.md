# neural_framework
Simple, but yet powerful neural computation framework for fast prototyping.
